"""DocuMind configuration — all paths, constants, and parameters."""

import os

# Base data directory (mounted volume in Docker)
DATA_DIR = os.environ.get("DOCUMIND_DATA_DIR", "/data")
ORIGINALS_DIR = os.path.join(DATA_DIR, "originals")
DB_PATH = os.path.join(DATA_DIR, "documind.db")

# OpenRouter LLM settings
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
OPENROUTER_BASE_URL = os.environ.get(
    "OPENROUTER_BASE_URL",
    "https://openrouter.ai/api/v1",
)
OPENROUTER_MODEL = os.environ.get(
    "OPENROUTER_MODEL",
    "google/gemini-3.1-pro-preview",
)
LLM_TEMPERATURE = 0.1
LLM_MAX_TOKENS = 2048

# Embedding settings
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
EMBEDDING_CACHE_DIR = os.path.join(DATA_DIR, "models")

# OCR settings
OCR_LANGUAGES = "fra+eng+deu+ara"
MIN_TEXT_LENGTH_PER_PAGE = 50  # Below this, treat PDF page as scanned image

# Upload settings
MAX_UPLOAD_SIZE_MB = 50
SUPPORTED_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".webp"}

# Search settings
FTS_WEIGHT = 0.4
SEMANTIC_WEIGHT = 0.6
DEFAULT_SEARCH_TOP_K = 20

# Chat RAG settings
RAG_TOP_K_DOCS = 5
RAG_MAX_TOKENS_PER_DOC = 500

# Server settings
HOST = "0.0.0.0"
PORT = 8000

# ---------------------------------------------------------------------------
# Create required directories at import time
# ---------------------------------------------------------------------------
os.makedirs(ORIGINALS_DIR, exist_ok=True)
os.makedirs(EMBEDDING_CACHE_DIR, exist_ok=True)
